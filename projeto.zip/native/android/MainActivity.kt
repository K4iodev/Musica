package PLACEHOLDER

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "kaio/saf"
    private val requestFiles = 4101
    private val requestFolder = 4102
    private var pending: MethodChannel.Result? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioExtensions = setOf("mp3", "wav", "flac", "m4a", "ogg", "aac", "aiff", "aif", "opus")

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickFiles" -> startPicker(result, requestFiles)
                    "pickFolder" -> startPicker(result, requestFolder)
                    "listAudio" -> {
                        val tree = call.argument<String>("treeUri")
                        if (tree == null) {
                            result.error("ARGUMENTO", "treeUri ausente", null)
                        } else {
                            listAudio(tree, result)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun startPicker(result: MethodChannel.Result, code: Int) {
        if (pending != null) {
            result.error("OCUPADO", "Já existe um seletor aberto", null)
            return
        }
        pending = result
        val intent = if (code == requestFiles) {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "application/ogg"))
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }
        }
        try {
            startActivityForResult(intent, code)
        } catch (e: Exception) {
            pending = null
            result.error("SEM_SELETOR", e.message, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestFiles && requestCode != requestFolder) return
        val result = pending ?: return
        pending = null
        if (resultCode != Activity.RESULT_OK || data == null) {
            result.success(null)
            return
        }
        if (requestCode == requestFolder) {
            val tree = data.data
            if (tree == null) {
                result.success(null)
            } else {
                persist(tree)
                result.success(tree.toString())
            }
            return
        }
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                uris.add(clip.getItemAt(i).uri)
            }
        } else {
            data.data?.let { uris.add(it) }
        }
        worker.execute {
            val out = ArrayList<Map<String, Any?>>()
            for (uri in uris) {
                persist(uri)
                val info = describe(uri)
                if (info != null) out.add(info)
            }
            mainHandler.post { result.success(out) }
        }
    }

    private fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Nem todo provedor permite permissão persistente; a leitura atual continua válida.
        }
    }

    private fun describe(uri: Uri): Map<String, Any?>? {
        return try {
            val projection = arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
            contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0) ?: (uri.lastPathSegment ?: "Faixa")
                    val size = if (cursor.isNull(1)) 0L else cursor.getLong(1)
                    mapOf<String, Any?>(
                        "uri" to uri.toString(),
                        "name" to name,
                        "size" to size,
                        "mime" to contentResolver.getType(uri)
                    )
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun isAudio(name: String, mime: String?): Boolean {
        if (mime != null && (mime.startsWith("audio/") || mime == "application/ogg")) return true
        return audioExtensions.contains(name.substringAfterLast('.', "").lowercase())
    }

    private fun listAudio(treeUriString: String, result: MethodChannel.Result) {
        worker.execute {
            try {
                val tree = Uri.parse(treeUriString)
                val rootId = DocumentsContract.getTreeDocumentId(tree)
                val found = ArrayList<Map<String, Any?>>()
                walk(tree, rootId, found, 0)
                mainHandler.post { result.success(found) }
            } catch (e: Exception) {
                mainHandler.post { result.error("LEITURA_FALHOU", e.message, null) }
            }
        }
    }

    private fun walk(tree: Uri, documentId: String, out: MutableList<Map<String, Any?>>, depth: Int) {
        if (depth > 15) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, documentId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        val folders = ArrayList<String>()
        contentResolver.query(children, columns, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getString(0) ?: ""
                val name = cursor.getString(1) ?: ""
                val mime = cursor.getString(2)
                if (id.isNotEmpty() && name.isNotEmpty()) {
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        folders.add(id)
                    } else if (isAudio(name, mime)) {
                        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        val size = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                        out.add(
                            mapOf<String, Any?>(
                                "uri" to doc.toString(),
                                "name" to name,
                                "size" to size,
                                "mime" to mime
                            )
                        )
                    }
                }
            }
        }
        for (folderId in folders) {
            walk(tree, folderId, out, depth + 1)
        }
    }
}
