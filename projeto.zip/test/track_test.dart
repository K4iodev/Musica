import 'package:flutter_test/flutter_test.dart';
import 'package:kaio_music/main.dart';

void main() {
  test('Track converte para JSON e volta sem perder dados', () {
    const original = Track(
      path: '/tmp/a.mp3',
      title: 'Teste',
      sourceName: 'a.mp3',
      sizeBytes: 1234,
    );
    final restored = Track.fromJson(original.toJson());
    expect(restored.path, original.path);
    expect(restored.title, original.title);
    expect(restored.sourceName, 'a.mp3');
    expect(restored.sizeBytes, 1234);
  });

  test('Track antigo (v0.2) sem campos novos ainda é lido', () {
    final restored = Track.fromJson({'path': '/tmp/b.mp3', 'title': 'Antiga'});
    expect(restored.sourceName, isNull);
    expect(restored.sizeBytes, isNull);
  });
}
