#!/usr/bin/env bash
# Executado pelo GitHub Actions depois do "flutter create".
# Instala o código nativo Android do KAIØ MUSIC (importação pelo SAF).
set -euo pipefail
MA=$(find android/app/src/main -name MainActivity.kt | head -n 1)
if [ -z "$MA" ]; then
  echo "MainActivity.kt não encontrado"
  exit 1
fi
PKG=$(grep -m1 '^package ' "$MA")
{ echo "$PKG"; tail -n +2 native/android/MainActivity.kt; } > "$MA"
echo "MainActivity.kt substituído em $MA ($PKG)"
