#!/usr/bin/env bash
# Compila o APK. Se algum plugin exigir compileSdk maior, aplica a correção e tenta de novo.
set -uo pipefail
cd "$(dirname "$0")/.."
mkdir -p ../logs
flutter build apk --release 2>&1 | tee ../logs/build.txt
if [ "${PIPESTATUS[0]}" -eq 0 ]; then exit 0; fi
if grep -q "compile against version" ../logs/build.txt; then
  echo "Plugin exige compileSdk maior. Aplicando correção e tentando de novo." | tee ../logs/retry.txt
  cat >> android/build.gradle.kts <<'KT'

subprojects {
    plugins.withId("com.android.library") {
        extensions.configure(com.android.build.api.dsl.LibraryExtension::class.java) {
            compileSdk = 36
        }
    }
    if (!state.executed) {
        afterEvaluate {
            extensions.findByType(com.android.build.api.dsl.LibraryExtension::class.java)?.compileSdk = 36
        }
    }
}
KT
  flutter build apk --release 2>&1 | tee ../logs/build2.txt
  exit "${PIPESTATUS[0]}"
fi
exit 1
