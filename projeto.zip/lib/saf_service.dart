import 'dart:io';

import 'package:flutter/services.dart';

/// Arquivo de áudio devolvido pelo Storage Access Framework do Android.
class SafAudioFile {
  const SafAudioFile({
    required this.uri,
    required this.name,
    required this.size,
    this.mime,
  });

  final String uri;
  final String name;
  final int size;
  final String? mime;

  factory SafAudioFile.fromMap(Map<dynamic, dynamic> map) => SafAudioFile(
    uri: map['uri'] as String,
    name: (map['name'] as String?) ?? 'Faixa',
    size: (map['size'] as num?)?.toInt() ?? 0,
    mime: map['mime'] as String?,
  );
}

/// Ponte entre o Flutter e o código nativo Android (MainActivity.kt).
/// As músicas são lidas pela URI, sem copiar os arquivos.
class SafService {
  static const MethodChannel _channel = MethodChannel('kaio/saf');

  static bool get isSupported => Platform.isAndroid;

  static bool isContentUri(String path) => path.startsWith('content://');

  /// Abre o seletor nativo e devolve os arquivos escolhidos (null se cancelado).
  Future<List<SafAudioFile>?> pickFiles() async {
    final raw = await _channel.invokeMethod<List<dynamic>>('pickFiles');
    if (raw == null) return null;
    return raw
        .map((item) => SafAudioFile.fromMap(item as Map<dynamic, dynamic>))
        .toList();
  }

  /// Abre o seletor de pastas e devolve a URI da pasta (null se cancelado).
  Future<String?> pickFolder() => _channel.invokeMethod<String>('pickFolder');

  /// Percorre a pasta e as subpastas e devolve os arquivos de áudio.
  Future<List<SafAudioFile>> listAudio(String treeUri) async {
    final raw = await _channel.invokeMethod<List<dynamic>>('listAudio', {
      'treeUri': treeUri,
    });
    return (raw ?? <dynamic>[])
        .map((item) => SafAudioFile.fromMap(item as Map<dynamic, dynamic>))
        .toList();
  }
}
