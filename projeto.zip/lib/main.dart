import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const KaioMusicApp());

class KaioMusicApp extends StatelessWidget {
  const KaioMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    const neon = Color(0xFFB56CFF);
    return MaterialApp(
      title: 'KAIØ MUSIC',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090711),
        colorScheme: ColorScheme.fromSeed(
          seedColor: neon,
          brightness: Brightness.dark,
          surface: const Color(0xFF151020),
        ),
        useMaterial3: true,
      ),
      home: const LibraryPage(),
    );
  }
}

class Track {
  const Track({
    required this.path,
    required this.title,
    this.sourceName,
    this.sizeBytes,
  });

  final String path;
  final String title;
  final String? sourceName;
  final int? sizeBytes;

  Map<String, dynamic> toJson() => {
    'path': path,
    'title': title,
    if (sourceName != null) 'sourceName': sourceName,
    if (sizeBytes != null) 'sizeBytes': sizeBytes,
  };

  factory Track.fromJson(Map<String, dynamic> json) => Track(
    path: json['path'] as String,
    title: json['title'] as String,
    sourceName: json['sourceName'] as String?,
    sizeBytes: json['sizeBytes'] as int?,
  );
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});

  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  static const _audioExtensions = {
    '.mp3',
    '.wav',
    '.flac',
    '.m4a',
    '.ogg',
    '.aac',
    '.aiff',
  };
  static const _libraryKey = 'kaio_music_library_v2';

  final AudioPlayer _player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _subs = [];
  final List<Track> _tracks = [];
  int? _currentIndex;
  bool _busy = false;
  String _message = 'Importe suas músicas para começar.';
  bool _shuffle = false;

  @override
  void initState() {
    super.initState();
    _restoreLibrary();
    _subs.add(
      _player.processingStateStream.listen((state) {
        if (state == ProcessingState.completed) _onCompleted();
      }),
    );
    _subs.add(
      _player.playerStateStream.listen((_) {
        if (mounted) setState(() {});
      }),
    );
  }

  Future<Directory> _managedMusicFolder() async {
    final docs = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(docs.path, 'KAIOMusic', 'Music'));
    if (!await folder.exists()) {
      await folder.create(recursive: true);
    }
    return folder;
  }

  Future<void> _restoreLibrary() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_libraryKey);
    if (raw == null) return;

    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      final restored = decoded
          .map((item) => Track.fromJson(item as Map<String, dynamic>))
          .where((track) => File(track.path).existsSync())
          .toList();
      if (mounted) {
        setState(() {
          _tracks
            ..clear()
            ..addAll(restored);
          _message = '${restored.length} música(s) na biblioteca.';
        });
      }
      await _saveLibrary();
    } catch (_) {
      if (mounted)
        setState(() => _message = 'Não foi possível recuperar a biblioteca.');
    }
  }

  Future<void> _saveLibrary() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _libraryKey,
      jsonEncode(_tracks.map((track) => track.toJson()).toList()),
    );
  }

  bool _isAudio(String path) =>
      _audioExtensions.contains(p.extension(path).toLowerCase());

  Future<void> _addCopiedFile(String sourcePath) async {
    if (!_isAudio(sourcePath)) return;
    final source = File(sourcePath);
    if (!await source.exists()) return;

    final originalName = p.basename(sourcePath);
    final size = await source.length();
    if (_tracks.any(
      (t) => t.sourceName == originalName && t.sizeBytes == size,
    )) {
      return;
    }
    final folder = await _managedMusicFolder();
    final uniqueName = '${DateTime.now().microsecondsSinceEpoch}_$originalName';
    final destination = p.join(folder.path, uniqueName);

    try {
      await source.copy(destination);
      final title = p.basenameWithoutExtension(originalName);
      _tracks.add(
        Track(
          path: destination,
          title: title,
          sourceName: originalName,
          sizeBytes: size,
        ),
      );
    } catch (_) {
      // Ignora arquivos que perderam acesso ou não puderam ser copiados.
    }
  }

  Future<void> _importFiles() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = 'Abrindo seletor de arquivos...';
    });

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: true,
        withData: false,
      );
      if (result == null) {
        if (mounted) setState(() => _message = 'Importação cancelada.');
        return;
      }

      var before = _tracks.length;
      for (final item in result.files) {
        final path = item.path;
        if (path != null) await _addCopiedFile(path);
      }
      await _saveLibrary();
      if (mounted) {
        setState(
          () => _message =
              '${_tracks.length - before} nova(s) música(s) adicionada(s).',
        );
      }
    } catch (error) {
      if (mounted) setState(() => _message = 'Falha na importação: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _importFolder() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = 'Selecione uma pasta com músicas...';
    });

    try {
      final folderPath = await FilePicker.platform.getDirectoryPath();
      if (folderPath == null) {
        if (mounted) {
          setState(
            () => _message =
                'Pasta não selecionada ou não suportada neste dispositivo.',
          );
        }
        return;
      }

      final folder = Directory(folderPath);
      if (!await folder.exists()) {
        if (mounted) setState(() => _message = 'A pasta não está acessível.');
        return;
      }

      final before = _tracks.length;
      await for (final entity in folder.list(
        recursive: true,
        followLinks: false,
      )) {
        if (entity is File && _isAudio(entity.path)) {
          await _addCopiedFile(entity.path);
        }
      }
      await _saveLibrary();

      if (mounted) {
        setState(
          () => _message =
              '${_tracks.length - before} nova(s) música(s) encontrada(s).',
        );
      }
    } catch (error) {
      if (mounted) {
        setState(
          () => _message =
              'Não foi possível ler a pasta. Verifique o suporte/permissões: $error',
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _play(int index) async {
    try {
      await _player.setFilePath(_tracks[index].path);
      if (!mounted) return;
      setState(() => _currentIndex = index);
      await _player.play();
    } catch (error) {
      if (mounted) {
        setState(
          () => _message = 'Não foi possível reproduzir esta faixa: $error',
        );
      }
    }
  }

  Future<void> _togglePlayback() async {
    if (_currentIndex == null) {
      if (_tracks.isNotEmpty) await _play(0);
      return;
    }
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    if (mounted) setState(() {});
  }

  Future<void> _next() async {
    if (_tracks.isEmpty) return;
    var next = ((_currentIndex ?? -1) + 1) % _tracks.length;
    if (_shuffle && _tracks.length > 1) {
      final random = Random();
      next = random.nextInt(_tracks.length);
      while (next == _currentIndex) {
        next = random.nextInt(_tracks.length);
      }
    }
    await _play(next);
  }

  Future<void> _previous() async {
    if (_tracks.isEmpty) return;
    if (_player.position > const Duration(seconds: 3)) {
      await _player.seek(Duration.zero);
      return;
    }
    final previous =
        ((_currentIndex ?? 0) - 1 + _tracks.length) % _tracks.length;
    await _play(previous);
  }

  Future<void> _onCompleted() async {
    if (_tracks.isEmpty) return;
    final isLast = _currentIndex == _tracks.length - 1;
    if (!_shuffle && isLast) {
      await _player.pause();
      await _player.seek(Duration.zero);
      return;
    }
    await _next();
  }

  Future<void> _removeTrack(int index) async {
    final track = _tracks.removeAt(index);
    try {
      final managed = await _managedMusicFolder();
      if (p.isWithin(managed.path, track.path)) {
        await File(track.path).delete();
      }
    } catch (_) {
      // Se não for possível apagar a cópia interna, a faixa sai da biblioteca mesmo assim.
    }
    if (_currentIndex == index) {
      await _player.stop();
      _currentIndex = null;
    } else if (_currentIndex != null && _currentIndex! > index) {
      _currentIndex = _currentIndex! - 1;
    }
    await _saveLibrary();
    if (mounted) {
      setState(() => _message = '"${track.title}" removida da biblioteca.');
    }
  }

  @override
  void dispose() {
    for (final sub in _subs) {
      sub.cancel();
    }
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const violet = Color(0xFFB56CFF);
    final currentTitle = _currentIndex == null
        ? 'Nenhuma faixa selecionada'
        : _tracks[_currentIndex!].title;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: const LinearGradient(
                        colors: [Color(0xFFB56CFF), Color(0xFF54228B)],
                      ),
                    ),
                    child: const Icon(Icons.graphic_eq, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'KAIØ MUSIC',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                        Text(
                          'YOUR SOUND. YOUR UNIVERSE.',
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 9,
                            letterSpacing: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Em breve: configurações',
                    onPressed: () =>
                        _toast('Configurações entram na próxima etapa.'),
                    icon: const Icon(Icons.tune, color: violet),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 18),
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF3A1B5B),
                          Color(0xFF1A1028),
                          Color(0xFF0D0B15),
                        ],
                      ),
                      border: Border.all(color: violet.withOpacity(.42)),
                      boxShadow: [
                        BoxShadow(
                          color: violet.withOpacity(.10),
                          blurRadius: 24,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'SUA MÚSICA. SUAS REGRAS.',
                          style: TextStyle(
                            color: Color(0xFFE0C3FF),
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Entre no seu\npróprio universo.',
                          style: TextStyle(
                            fontSize: 28,
                            height: 1.1,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: _busy ? null : _importFiles,
                                icon: const Icon(Icons.audio_file),
                                label: const Text('Arquivos'),
                                style: FilledButton.styleFrom(
                                  backgroundColor: violet,
                                  foregroundColor: Colors.black,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: _busy ? null : _importFolder,
                                icon: const Icon(Icons.folder_open),
                                label: const Text('Pastas'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  side: BorderSide(
                                    color: violet.withOpacity(.7),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'SUA BIBLIOTECA',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      Text(
                        '${_tracks.length} FAIXAS',
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 10,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _message,
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                  if (_busy)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(
                        child: CircularProgressIndicator(color: violet),
                      ),
                    )
                  else if (_tracks.isEmpty)
                    Container(
                      margin: const EdgeInsets.only(top: 14),
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        color: const Color(0xFF151020),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: const Column(
                        children: [
                          Icon(
                            Icons.library_music_outlined,
                            color: violet,
                            size: 42,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'Sua biblioteca está vazia',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 6),
                          Text(
                            'Use Arquivos ou Pastas para adicionar suas músicas.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ...List.generate(_tracks.length, (index) {
                      final track = _tracks[index];
                      final selected = index == _currentIndex;
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 4,
                        ),
                        leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF28183B),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            selected ? Icons.equalizer : Icons.music_note,
                            color: violet,
                          ),
                        ),
                        title: Text(
                          track.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: const Text(
                          'Áudio local',
                          style: TextStyle(color: Colors.white54, fontSize: 11),
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'remove') _removeTrack(index);
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'remove',
                              child: Text('Remover da biblioteca'),
                            ),
                          ],
                          child: const Icon(
                            Icons.more_vert,
                            color: Colors.white54,
                          ),
                        ),
                        onTap: () => _play(index),
                      );
                    }),
                ],
              ),
            ),
            _playerBar(currentTitle, violet),
          ],
        ),
      ),
    );
  }

  Widget _playerBar(String title, Color violet) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: const BoxDecoration(
        color: Color(0xFF151020),
        border: Border(top: BorderSide(color: Colors.white10)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.album, color: Color(0xFFB56CFF), size: 34),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              IconButton(
                tooltip: _shuffle ? 'Desativar aleatório' : 'Ativar aleatório',
                onPressed: () => setState(() => _shuffle = !_shuffle),
                icon: Icon(
                  Icons.shuffle,
                  color: _shuffle ? violet : Colors.white38,
                  size: 20,
                ),
              ),
              IconButton(
                tooltip: 'Faixa anterior',
                onPressed: _previous,
                icon: const Icon(Icons.skip_previous, size: 28),
              ),
              IconButton(
                onPressed: _togglePlayback,
                icon: Icon(
                  _player.playing ? Icons.pause_circle : Icons.play_circle,
                  color: violet,
                  size: 36,
                ),
              ),
              IconButton(
                onPressed: _next,
                icon: const Icon(Icons.skip_next, size: 28),
              ),
            ],
          ),
          StreamBuilder<Duration?>(
            stream: _player.durationStream,
            builder: (context, durationSnapshot) {
              final duration = durationSnapshot.data ?? Duration.zero;
              return StreamBuilder<Duration>(
                stream: _player.positionStream,
                builder: (context, positionSnapshot) {
                  final position = positionSnapshot.data ?? Duration.zero;
                  final max = duration.inMilliseconds.toDouble();
                  final value = max <= 0
                      ? 0.0
                      : position.inMilliseconds
                            .clamp(0, duration.inMilliseconds)
                            .toDouble();
                  return Slider(
                    value: value,
                    max: max <= 0 ? 1 : max,
                    onChanged: max <= 0
                        ? null
                        : (v) =>
                              _player.seek(Duration(milliseconds: v.round())),
                    activeColor: violet,
                    inactiveColor: Colors.white12,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}
