# KAIØ MUSIC — v0.2.0

Aplicativo multiplataforma em Flutter para organizar e reproduzir arquivos de música locais, com interface Cyberpunk Premium.

## O que esta versão contém
- Interface inicial responsiva.
- Importação manual de vários arquivos de áudio.
- Seleção de pasta e varredura recursiva quando a plataforma fornece um caminho de diretório.
- Cópia dos arquivos importados para a área privada do aplicativo.
- Persistência da lista da biblioteca usando SharedPreferences.
- Reprodução local com play/pause, próxima faixa, aleatório simples e barra de progresso.
- Remoção de uma faixa da biblioteca sem apagar o arquivo original importado.
- Formatos reconhecidos: MP3, WAV, FLAC, M4A, OGG, AAC e AIFF.

## Requisitos
- Flutter SDK (Dart 3.3 ou superior).
- Android Studio para compilar Android.
- Windows + Visual Studio com workload "Desktop development with C++" para compilar Windows.

## Como executar
1. Extraia o ZIP.
2. Abra a pasta do projeto no terminal.
3. Execute:
   ```bash
   flutter pub get
   flutter run
   ```
4. Para Android:
   ```bash
   flutter run -d <android-device>
   ```
5. Para Windows:
   ```bash
   flutter config --enable-windows-desktop
   flutter run -d windows
   ```

## Observações importantes sobre importação
A importação manual usa o seletor de documentos do sistema, evitando pedir acesso amplo ao armazenamento.
A seleção de pasta depende do suporte do seletor na versão do Android e no provedor de arquivos. Em alguns aparelhos, o Android retorna uma URI de documento em vez de um caminho de arquivo tradicional. Nesses casos, será necessário implementar um adaptador Android nativo com Storage Access Framework (SAF) para ler pastas recursivamente de forma confiável.
No Windows, a seleção e a varredura recursiva de pastas locais são suportadas pelo caminho de diretório retornado pelo plugin.

## Limitações conhecidas da versão 0.2
- A biblioteca persiste os caminhos dos arquivos copiados para a pasta privada do app.
- Ainda não lê tags ID3, capas, artista, álbum ou duração para preencher metadados.
- O modo aleatório é uma seleção simples, não um algoritmo que evita repetir a faixa atual.
- Não há ainda reprodução em segundo plano, notificações de mídia ou integração com controles da tela bloqueada.
- Não há ainda playlists, favoritos ou busca.

## Próxima etapa sugerida — v0.3
1. Integração SAF Android nativa para importação de pastas e atualização da biblioteca.
2. Metadados e capas de álbuns.
3. Busca, playlists e favoritos.
4. Reprodução em segundo plano e controles de mídia.
5. Testes de compilação e reprodução em dispositivos Android e Windows.

## Alterações da v0.2.1 (Etapa 2 da v0.3)
- Corrigido o texto da tela inicial, que mostrava "\n" literal.
- A faixa seguinte toca sozinha quando uma música termina. Sem aleatório, a reprodução para na última faixa.
- O modo aleatório não repete mais a faixa atual.
- Novo botão de faixa anterior (volta ao início se passaram mais de 3 segundos).
- Importar o mesmo arquivo de novo não cria uma cópia duplicada (compara nome e tamanho).
- Remover uma faixa apaga só a cópia interna do app, nunca o arquivo original.
- O ícone de play/pause acompanha o estado real do player.
- Adicionados analysis_options.yaml e um teste simples (test/track_test.dart).
- Estado de verificação: a sintaxe foi validada com o Dart SDK 3.14. `flutter analyze`, `flutter test` e as compilações NÃO foram executados (ver observações da entrega).

## Versão 0.3.0-alpha.1 (Etapa 3: SAF no Android)
- Android: importar músicas e pastas pelo seletor nativo (Storage Access Framework). As músicas são lidas pela URI, sem copiar os arquivos, com permissão persistente.
- Pastas são percorridas com as subpastas (`native/android/MainActivity.kt`).
- A reprodução aceita URIs `content://` além de caminhos de arquivo.
- Windows e demais: o `file_picker` foi trocado pelo `file_selector` (pacote oficial do Flutter), que também elimina o erro de `compileSdk` no Android.
- `tool/ci_prepare.sh` e `tool/ci_build_android.sh` são usados só pelo GitHub Actions.
- Estado: código escrito, ainda não compilado nem testado em aparelho.
